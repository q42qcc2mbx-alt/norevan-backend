// Einstiegspunkt. Bewusst dünn gehalten: Konfig laden, App zusammenstecken, lauschen.
import 'dotenv/config';
import express from 'express';

// Import löst den DB-Init-Code in config/database.js aus (Side Effect by design).
import './config/database.js';
import authRoutes from './routes/authRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';

// Harter Stopp, wenn das JWT-Secret fehlt – lieber jetzt crashen als
// später mit einem unsicheren Default weiterlaufen.
if (!process.env.JWT_SECRET) {
  console.error('[FATAL] JWT_SECRET ist nicht gesetzt. Siehe .env.example.');
  process.exit(1);
}

const app = express();

// JSON-Bodyparser mit Limit – Standardhärtung gegen oversized Payloads.
app.use(express.json({ limit: '10kb' }));

// Routen unter klaren Prefixen mounten – /api/* macht Reverse-Proxy-Setup einfacher.
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);

// 404 für unbekannte Routen.
app.use((req, res) => res.status(404).json({ error: 'Nicht gefunden.' }));

// Zentraler Error-Handler als Sicherheitsnetz, falls eine Route mal `next(err)` aufruft.
app.use((err, _req, res, _next) => {
  console.error('[unhandled]', err);
  res.status(500).json({ error: 'Interner Serverfehler.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`[server] Läuft auf http://localhost:${PORT}`);
});
