// JWT-Schutz für private Routen.
// Wir lesen den Token aus dem Authorization-Header ("Bearer <token>") – Standard nach RFC 6750.
import jwt from 'jsonwebtoken';

export function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];

  // Frühzeitig abbrechen, wenn gar kein Header da ist – spart Verifikations-Aufwand.
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Kein Token bereitgestellt.' });
  }

  const token = authHeader.slice(7); // "Bearer ".length === 7

  try {
    // jwt.verify wirft bei ungültiger Signatur ODER abgelaufenem Token –
    // beides wollen wir gleich behandeln (=> 401), Details bleiben absichtlich vage,
    // damit ein Angreifer keine Infos über die Ursache bekommt.
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = { id: payload.sub, username: payload.username };
    next();
  } catch {
    return res.status(401).json({ error: 'Token ungültig oder abgelaufen.' });
  }
}
