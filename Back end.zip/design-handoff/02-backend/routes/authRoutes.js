// Auth-Endpunkte: /register und /login.
// Bewusst keine Business-Logik in server.js – Routen bleiben thematisch gebündelt.
import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { dbGet, dbRun } from '../config/database.js';

const router = Router();

// bcrypt-Cost: 12 ist 2025/2026 ein vernünftiger Default – langsam genug gegen Brute-Force,
// schnell genug für interaktive Logins (< 250ms auf üblicher Hardware).
const SALT_ROUNDS = 12;

// Minimal-Validierung. In Produktion würde man z. B. zod/joi einsetzen –
// hier reicht ein kurzer Guard, damit die Route nicht zur Schwachstelle wird.
function validateCredentials(body) {
  const { username, password } = body ?? {};
  if (typeof username !== 'string' || username.trim().length < 3) {
    return 'Username muss mindestens 3 Zeichen lang sein.';
  }
  if (typeof password !== 'string' || password.length < 8) {
    return 'Passwort muss mindestens 8 Zeichen lang sein.';
  }
  return null;
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const error = validateCredentials(req.body);
  if (error) return res.status(400).json({ error });

  const username = req.body.username.trim();
  const password = req.body.password;

  try {
    // Passwort NIE im Klartext speichern – bcrypt erzeugt Salt + Hash in einem Schritt.
    const password_hash = await bcrypt.hash(password, SALT_ROUNDS);

    const result = await dbRun(
      'INSERT INTO users (username, password_hash) VALUES (?, ?)',
      [username, password_hash]
    );

    // 201 Created statt 200 – semantisch korrekter für "Ressource erstellt".
    return res.status(201).json({ id: result.lastID, username });
  } catch (err) {
    // SQLITE_CONSTRAINT → UNIQUE-Verletzung auf username.
    if (err && err.code === 'SQLITE_CONSTRAINT') {
      return res.status(409).json({ error: 'Username ist bereits vergeben.' });
    }
    console.error('[register] Fehler:', err);
    return res.status(500).json({ error: 'Interner Serverfehler.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const error = validateCredentials(req.body);
  if (error) return res.status(400).json({ error });

  const username = req.body.username.trim();
  const password = req.body.password;

  try {
    const user = await dbGet(
      'SELECT id, username, password_hash FROM users WHERE username = ?',
      [username]
    );

    // Gleiche Fehlermeldung für "User existiert nicht" UND "falsches Passwort" –
    // verhindert Username-Enumeration über die Login-Route.
    const ok = user ? await bcrypt.compare(password, user.password_hash) : false;
    if (!ok) {
      return res.status(401).json({ error: 'Ungültige Zugangsdaten.' });
    }

    // `sub` (subject) ist der JWT-Standardclaim für die Nutzer-ID.
    const token = jwt.sign(
      { sub: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '1h' }
    );

    return res.json({ token, tokenType: 'Bearer' });
  } catch (err) {
    console.error('[login] Fehler:', err);
    return res.status(500).json({ error: 'Interner Serverfehler.' });
  }
});

export default router;
