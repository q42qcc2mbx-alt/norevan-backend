// Geschützte Beispiel-Route. Die Middleware übernimmt die Verifikation;
// hier interessiert uns nur, was wir mit `req.user` machen.
import { Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = Router();

// GET /api/dashboard – nur mit gültigem Bearer-Token erreichbar.
router.get('/', authMiddleware, (req, res) => {
  res.json({
    message: `Willkommen, User #${req.user.id}.`,
    user: req.user,
  });
});

export default router;
