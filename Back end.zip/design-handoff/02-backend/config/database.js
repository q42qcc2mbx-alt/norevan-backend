// Zentrale DB-Initialisierung. Wird einmal beim Start importiert,
// damit die SQLite-Datei und Tabellen garantiert vorhanden sind.
import sqlite3pkg from 'sqlite3';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const sqlite3 = sqlite3pkg.verbose();

// __dirname-Ersatz für ES Modules – wir wollen die DB-Datei relativ zum Projekt ablegen.
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, '..', 'data.sqlite');

// Eine einzige Connection im gesamten Prozess – sqlite3 serialisiert Writes von Haus aus,
// und für ein simples Auth-Backend reicht das vollkommen.
const db = new sqlite3pkg.Database(DB_PATH, (err) => {
  if (err) {
    console.error('[DB] Verbindung fehlgeschlagen:', err.message);
    process.exit(1);
  }
  console.log(`[DB] Verbunden mit ${DB_PATH}`);
});

// Tabelle direkt beim Start anlegen, falls sie noch nicht existiert.
// UNIQUE auf username verhindert doppelte Accounts schon auf DB-Ebene.
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      username      TEXT    NOT NULL UNIQUE,
      password_hash TEXT    NOT NULL,
      created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
});

// Kleine Promise-Wrapper, damit Routen async/await nutzen können
// statt überall mit Callbacks zu hantieren.
export const dbGet = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
  });

export const dbRun = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      // `function` (kein Arrow), weil wir `this.lastID` brauchen.
      if (err) return reject(err);
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });

export default db;
