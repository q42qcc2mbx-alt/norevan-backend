# Norevan · Backend Atelier — Handoff-Paket

Übergabe an die Entwicklung. Enthält **zwei Teile**: die Designs (HTML/React + CSS) und den Backend-Code (Node/Express + SQLite).

```
design-handoff/
├── README.md                ← du bist hier
├── 01-design/               ← Designs als interaktive HTML-Mockups
│   ├── Backend Atelier.html ← Einstiegspunkt (alle Screens in einer Canvas)
│   ├── styles.css           ← komplettes Stylesheet, alle Tokens via var(--*)
│   ├── atoms.jsx            ← Eyebrow, Pill, Field, NorevanMark (Logo-SVG)…
│   ├── app.jsx              ← Login, Registrierung, Dashboard + Mount
│   ├── commerce.jsx         ← Warenkorb, Bezahlung
│   ├── comms.jsx            ← E-Mail-Template, Support-Chat
│   ├── returns.jsx          ← Rückgabe (Methode wählen + QR-Bestätigung)
│   ├── design-canvas.jsx    ← Review-Wrapper, NICHT in Produktion übernehmen
│   └── assets/
│       ├── tokens.css       ← Design-Tokens: Farben, Typo, Spacing, Radius
│       ├── norevan-logo.png ← Original-Logo (Bitmap, fallback)
│       ├── lifestyle-*.jpg  ← Hero-/Atmosphären-Bilder
│       └── product-*.png    ← Produktbilder für Cart / Checkout
└── 02-backend/              ← Lauffähiges Auth-Backend
    ├── package.json
    ├── .env.example
    ├── .gitignore
    ├── server.js
    ├── config/database.js
    ├── middleware/authMiddleware.js
    └── routes/
        ├── authRoutes.js
        └── dashboardRoutes.js
```

---

## 1) Design

### Screens (Reihenfolge in der Canvas)

| Sektion       | Screen                       | Datei         | Zweck                                                       |
|---------------|------------------------------|---------------|-------------------------------------------------------------|
| Auth          | Login                        | `app.jsx`     | Anmeldung — POST `/api/auth/login`                          |
| Auth          | Registrierung                | `app.jsx`     | Konto anlegen — POST `/api/auth/register`                   |
| Dashboard     | Member Dashboard             | `app.jsx`     | Geschützte Route — GET `/api/dashboard`                     |
| Commerce      | Warenkorb                    | `commerce.jsx`| Tabellen-Layout mit Mengen-Steppern und Summary             |
| Commerce      | Bezahlung                    | `commerce.jsx`| Versandart + Bezahlmethode (Karte/PayPal/Apple Pay/Klarna)  |
| Comms         | E-Mail-Template              | `comms.jsx`   | Typografische Welcome-Mail mit Mitgliedskarte               |
| Comms         | Support-Chat                 | `comms.jsx`   | Atelier-Support mit Bubbles, Anhängen, typing-indicator     |
| Rückgabe      | Methode wählen               | `returns.jsx` | QR-Code / PDF-Label / Hausabholung                          |
| Rückgabe      | Bestätigung mit QR           | `returns.jsx` | Inline-SVG QR-Code + Anleitung + DHL-Filialfinder           |

### Design-System (kurz)

- **Farben:** warmes Ivory-Champagne `#f7f3ea` auf Espresso `#1c1612`. Akzent: Gold `#c8a96a` (nur im Logo).
- **Typografie:** Display = *Cormorant Garamond* (oft italic), Body = *Geist*, Mono = *Geist Mono*. Eyebrows: 11px ALL-CAPS mit 0.35em tracking.
- **Easing:** alle Animationen `cubic-bezier(0.2, 0.8, 0.2, 1)` (250–700ms).
- **Radien:** `--radius-sm` 2px (Produktbilder, Cards), `--radius-pill` für Buttons. **Keine Drop-Shadows auf Cards.**
- **Komplette Token-Liste** in `01-design/assets/tokens.css` (39 CSS-Variablen). **Bitte 1:1 in die Produktion übernehmen** — `styles.css` referenziert ausschließlich diese Tokens, keine hartcodierten Farben.

### Integration in die echte Site

1. **Tokens übernehmen:** `assets/tokens.css` in den globalen Stylesheet kippen.
2. **Components rebuilden:** die JSX in `atoms.jsx`, `commerce.jsx`, `comms.jsx`, `returns.jsx` ist Vanilla-React ohne externe Dependencies (außer React selbst). Konvertierung nach Next.js/TS sollte 1:1 möglich sein — Klassen-Namen bleiben, Markup bleibt.
3. **Logo:** ist **inline SVG** in `atoms.jsx` (`<NorevanShield />` + `<NorevanMark variant="…">`). Drei Varianten: `horizontal`, `stacked`, `icon`, `wordmark`. Bitmap-Logo bitte nicht mehr verwenden.
4. **QR-Code:** in `returns.jsx` ist die `<QRCode />`-Komponente ein dekoratives Pseudo-Muster. Vor Live-Gang durch echte Library ersetzen (z. B. `qrcode` von npm), API: gleiche Props (`size`, `seed` → echter Payload).
5. **`design-canvas.jsx`** ist nur der Review-Wrapper für die Mockup-Seite — in der Produktion **nicht** verwenden, die einzelnen Screens als eigene Routes/Seiten mounten.

### Mockup lokal öffnen

`01-design/Backend Atelier.html` direkt im Browser öffnen — React + Babel werden via CDN geladen, kein Build nötig. Auf der Canvas:
- Scrollen / Mausrad zum Pannen, ⌘/Strg + Scroll zum Zoomen
- Doppelklick auf ein Artboard → Fullscreen-Fokus, ←/→ zwischen Screens, Esc zum Verlassen

---

## 2) Backend

Sicheres Auth-System mit JWT (HS256, 1h TTL), bcrypt (cost 12), SQLite mit Auto-Init.

### Endpunkte

| Methode | Route                   | Body / Header                           | Antwort |
|---------|--------------------------|------------------------------------------|---------|
| POST    | `/api/auth/register`    | `{ username, password }`                | `201 { id, username }` / `409` falls vergeben |
| POST    | `/api/auth/login`       | `{ username, password }`                | `200 { token, tokenType: 'Bearer' }` / `401` |
| GET     | `/api/dashboard`        | Header `Authorization: Bearer <token>`  | `200 { message, user }` / `401` |

### Start in 3 Schritten

```bash
cd 02-backend
npm install
cp .env.example .env   # JWT_SECRET durch langen Zufallswert ersetzen
npm start              # läuft auf http://localhost:3000
```

### Sicherheits-Hinweise für den Live-Gang

- `.env` **niemals** committen (bereits in `.gitignore`).
- `JWT_SECRET` per `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` generieren und sicher ablegen (Vault/Secrets-Manager).
- Vor Produktion ergänzen: Rate-Limiting (`express-rate-limit`), Helmet (`helmet`), CORS-Whitelist, Input-Validation (`zod`/`joi`), HTTPS-Termination via Reverse-Proxy.
- Login-Route gibt absichtlich dieselbe Fehlermeldung bei „User nicht existent" und „falsches Passwort" zurück — verhindert User-Enumeration. Bitte beibehalten.
- DB-Datei `data.sqlite` wird beim ersten Start automatisch erzeugt. Für Produktion ggf. auf Postgres umstellen (Tabellen-Schema 1:1 portierbar).

---

## Kontakt / Fragen

Beim Hochziehen Fragen einfach zurückmelden — die Components sind bewusst klein und ohne externe State-Logik gehalten, damit sie in jedem Frontend-Stack landen können (Next.js, Astro, plain HTML, etc.).

Made with code &amp; coffee.
