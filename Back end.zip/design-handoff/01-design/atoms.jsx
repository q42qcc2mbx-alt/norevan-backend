/* global React */
// Atomare UI-Bausteine, von mehreren Screens geteilt.
// Werden über window exportiert, damit andere <script type="text/babel"> sie sehen können.

const Eyebrow = ({ children, className = '' }) => (
  <span className={`eyebrow ${className}`}>{children}</span>
);

const Mono = ({ children, className = '' }) => (
  <span className={`mono ${className}`}>{children}</span>
);

const Pill = ({ children, variant = 'solid', as = 'button', size, ...rest }) => {
  const Tag = as;
  return (
    <Tag className={`pill pill--${variant}${size ? ` pill--${size}` : ''}`} {...rest}>
      <span className="button-label">{children}</span>
    </Tag>
  );
};

const Field = ({ label, hint, type = 'text', value, placeholder, autoFocus }) => (
  <label className="field">
    <span className="field__label">{label}</span>
    <input
      className="field__input"
      type={type}
      defaultValue={value}
      placeholder={placeholder}
      autoFocus={autoFocus}
    />
    {hint && <span className="field__hint">{hint}</span>}
  </label>
);

const Divider = ({ children }) => (
  <div className="divider">
    <span className="divider__line" />
    {children && <span className="divider__label mono">{children}</span>}
    <span className="divider__line" />
  </div>
);

const Logo = ({ size = 28 }) => (
  <div className="logo">
    <img src="assets/norevan-logo.png" alt="" style={{ height: size, objectFit: 'cover' }} />
  </div>
);

// ============================================================
// NOREVAN MARK — Inline SVG, transparent, currentColor
// Verwendet das italic "N" als Monogramm in einem dünnen
// achteckigen Schild + den NOREVAN-Wordmark.
// Variants:
//   "horizontal" — Schild links, Wordmark rechts (Default)
//   "stacked"    — Schild über Wordmark (für Hero-Email)
//   "icon"       — nur das Schild
//   "wordmark"   — nur der Schriftzug
// ============================================================
const NorevanShield = ({ size = 28, stroke = 1 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    stroke="currentColor"
    strokeWidth={stroke}
    aria-hidden="true"
  >
    {/* Achteckiges Schild – dünne Hairline, currentColor */}
    <path d="M16 4 L48 4 L60 16 L60 48 L48 60 L16 60 L4 48 L4 16 Z" />
    {/* Innerer Rand – nur Andeutung, sehr fein */}
    <path d="M18 8 L46 8 L56 18 L56 46 L46 56 L18 56 L8 46 L8 18 Z"
          opacity="0.35" />
    {/* Mittiges "N" – italic Cormorant über <text> */}
    <text
      x="32" y="44"
      textAnchor="middle"
      fontFamily='"Cormorant Garamond", Georgia, serif'
      fontSize="36"
      fontStyle="italic"
      fontWeight="400"
      fill="currentColor"
      stroke="none"
      letterSpacing="-0.02em"
    >N</text>
    {/* Mini-Punkt oben + unten als Atelier-Marke */}
    <circle cx="32" cy="14" r="0.9" fill="currentColor" stroke="none" />
    <circle cx="32" cy="50" r="0.9" fill="currentColor" stroke="none" />
  </svg>
);

const NorevanMark = ({ variant = 'horizontal', size, tagline = 'ATELIER · BERLIN', className = '' }) => {
  if (variant === 'icon') {
    return (
      <span className={`nmark nmark--icon ${className}`}>
        <NorevanShield size={size || 36} />
      </span>
    );
  }
  if (variant === 'wordmark') {
    return (
      <span className={`nmark nmark--wordmark ${className}`}>
        <span className="nmark__word">NOREVAN</span>
      </span>
    );
  }
  if (variant === 'stacked') {
    return (
      <span className={`nmark nmark--stacked ${className}`}>
        <NorevanShield size={size || 56} />
        <span className="nmark__rule" />
        <span className="nmark__word">NOREVAN</span>
        {tagline && <span className="nmark__tagline">{tagline}</span>}
      </span>
    );
  }
  // horizontal
  return (
    <span className={`nmark nmark--horizontal ${className}`}>
      <NorevanShield size={size || 28} />
      <span className="nmark__word">NOREVAN</span>
    </span>
  );
};

// Editorial site header — wird in Cart / Checkout wiederverwendet.
const SiteHeader = ({ cart = 3 }) => (
  <header className="site-header">
    <div className="site-header__left">
      <Mono className="muted-text">[NOREVAN]</Mono>
    </div>
    <nav className="site-header__nav">
      <a className="site-nav-item">Shop</a>
      <a className="site-nav-item">Marken</a>
      <a className="site-nav-item">Atelier</a>
      <a className="site-nav-item">Journal</a>
    </nav>
    <div className="site-header__right">
      <a className="site-nav-item">Suchen</a>
      <a className="site-nav-item">Konto</a>
      <a className="site-nav-item site-nav-item--cart">
        Warenkorb <Mono className="cart-count">{String(cart).padStart(2, '0')}</Mono>
      </a>
    </div>
  </header>
);

Object.assign(window, {
  Eyebrow, Mono, Pill, Field, Divider, Logo, SiteHeader,
  NorevanShield, NorevanMark,
});
