/* global React, Eyebrow, Mono, Pill, Logo */
const { useState, useEffect } = React;

// ============================================================
// EMAIL — Mailclient-Frame mit editorialem Template
// ============================================================
const EmailScreen = () => (
  <div className="screen mailclient">
    <header className="mailclient__chrome">
      <div className="window-dots">
        <span /><span /><span />
      </div>
      <div className="mailclient__tabs">
        <span className="mailclient__tab mailclient__tab--active">Posteingang</span>
        <span className="mailclient__tab">Gesendet</span>
        <span className="mailclient__tab">Archiv</span>
      </div>
      <Mono className="muted-text">norevan · mail</Mono>
    </header>

    <div className="mailclient__body">
      <aside className="mail-sidebar">
        <ul className="mail-list">
          {[
            ['Norevan Atelier', 'Willkommen, Alice.', '09:24', true],
            ['DHL Express', 'Sendung unterwegs.', 'Gestern', false],
            ['Norevan', 'Deine Bestellung #N-00428', 'Mo', false],
            ['Mara · Support', 'Re: Größe 43', 'So', false],
          ].map(([from, subject, time, active], i) => (
            <li key={i} className={`mail-row${active ? ' mail-row--active' : ''}`}>
              <span className="mail-row__from">{from}</span>
              <span className="mail-row__subject">{subject}</span>
              <Mono className="muted-text mail-row__time">{time}</Mono>
            </li>
          ))}
        </ul>
      </aside>

      <article className="mail-pane">
        <header className="mail-pane__head">
          <div className="mail-pane__meta">
            <Mono className="muted-text">Von</Mono>
            <span>Norevan Atelier &lt;atelier@norevan.com&gt;</span>
          </div>
          <div className="mail-pane__meta">
            <Mono className="muted-text">An</Mono>
            <span>alice@beispiel.de</span>
          </div>
          <Mono className="muted-text mail-pane__time">14. Mai 2026 · 09:24</Mono>
        </header>

        {/* Eigentliches Email-Template — typography-first, kein Foto */}
        <div className="email">
          <div className="email__hero email__hero--type">
            <div className="email__hero-corners">
              <span className="corner corner--tl" />
              <span className="corner corner--tr" />
              <span className="corner corner--bl" />
              <span className="corner corner--br" />
            </div>
            <div className="email__hero-content">
              <NorevanMark variant="stacked" tagline="ATELIER · BERLIN" />
              <span className="email__hero-rule" />
              <Mono className="email__hero-mono">Saison 2026 · Mitgliederzugang</Mono>
              <h1 className="headline email__hero-title">
                Willkommen, <span className="headline-italic">Alice.</span>
              </h1>
              <p className="email__hero-sub">
                Du bist drin. Das Atelier hat dich erwartet.
              </p>
            </div>
          </div>

          {/* Mitgliedskarte */}
          <div className="member-card">
            <div className="member-card__left">
              <Mono className="muted-text">Mitglied · seit 14. Feb 2026</Mono>
              <span className="member-card__name">Alice Müller</span>
            </div>
            <div className="member-card__id">
              <span className="member-card__hash">№</span>
              <span className="member-card__num">00042</span>
            </div>
            <div className="member-card__right">
              <Mono className="muted-text">Status</Mono>
              <span className="member-card__status"><span className="dot dot--ok" /> Aktiv</span>
            </div>
          </div>

          <div className="email__body">
            <p className="email__lede">
              <span className="dropcap">S</span>chön, dass du dabei bist. Norevan ist klein,
              kuratiert und ohne Lärm — wir tragen handverlesene Stücke, von denen
              jedes seinen Grund hat, hier zu sein.
            </p>

            <p>
              Dein Konto ist aktiv und mit deiner Mitgliedsnummer verknüpft.
              Drei Dinge, die ab sofort zu dir gehören:
            </p>

            {/* Privileges statt Produktbilder */}
            <ol className="privileges">
              {[
                ['01', 'Kostenloser Versand & Rückversand', 'Auf jede Bestellung — auch bei Größentausch.'],
                ['02', 'Erstzugriff auf neue Kollektionen', '48 Stunden vor allen anderen, freitags um 09:00.'],
                ['03', 'Atelier-Beratung per Chat', 'Größe unklar? Passform unsicher? Mara antwortet in zwei Minuten.'],
              ].map(([num, title, desc]) => (
                <li key={num} className="privilege">
                  <Mono className="privilege__num">{num}</Mono>
                  <div className="privilege__body">
                    <h4 className="privilege__title">{title}</h4>
                    <p className="privilege__desc">{desc}</p>
                  </div>
                </li>
              ))}
            </ol>

            <div className="email__cta">
              <Pill variant="solid" as="a" href="#">In den Shop →</Pill>
              <Mono className="muted-text">
                norevan.com · einloggen mit alice@beispiel.de
              </Mono>
            </div>

            <blockquote className="email__quote">
              <span className="email__quote-rule" />
              <p className="headline-italic">
                "Streetwear ohne Kompromisse. <br />
                Handverlesen. Authentisch. Kuratiert."
              </p>
              <Mono className="muted-text">— Atelier-Grundsatz</Mono>
            </blockquote>

            <div className="email__sign-block">
              <p className="email__sign-line">Mit besten Grüßen,</p>
              <p className="email__sign-name headline-italic">Mara &amp; das Atelier-Team</p>
            </div>
          </div>

          <footer className="email__footer">
            <div className="email__footer-mark">
              <NorevanMark variant="horizontal" size={20} />
            </div>
            <div className="email__footer-grid">
              <div>
                <Mono className="muted-text">Atelier</Mono>
                <p>Linienstraße 142<br />10115 Berlin</p>
              </div>
              <div>
                <Mono className="muted-text">Kontakt</Mono>
                <p>atelier@norevan.com<br />+49 30 1234 5678</p>
              </div>
              <div>
                <Mono className="muted-text">Folgen</Mono>
                <p>Instagram · Are.na<br />Substack · Spotify</p>
              </div>
            </div>
            <div className="email__footer-links">
              <a className="link link--muted">Konto verwalten</a>
              <span className="dot-sep" />
              <a className="link link--muted">Newsletter abbestellen</a>
              <span className="dot-sep" />
              <a className="link link--muted">Impressum</a>
              <span className="dot-sep" />
              <a className="link link--muted">Datenschutz</a>
            </div>
            <Mono className="muted-text email__footer-fine">
              Norevan GmbH · HRB 234567 B · Made with code &amp; coffee.
            </Mono>
          </footer>
        </div>
      </article>
    </div>
  </div>
);

// ============================================================
// CHAT — Support Atelier
// Mit animierten "tippt..."-Punkten und Bubble-Reveal.
// ============================================================
const messages = [
  { role: 'agent', name: 'Mara', time: '09:18', text: 'Guten Morgen Alice. Hier ist Mara aus dem Norevan Atelier. Wie kann ich helfen?' },
  { role: 'user', time: '09:19', text: 'Hi! Ich habe gestern den Tech Fleece in M bestellt — sitzt aber zu eng. Kann ich auf L umtauschen?' },
  { role: 'agent', name: 'Mara', time: '09:20', text: 'Klar, geht in zwei Minuten. Bestellung #N-00428, richtig?' },
  { role: 'user', time: '09:20', text: 'Genau die.' },
  { role: 'agent', name: 'Mara', time: '09:21', text: 'Ich tausche dir die Größe direkt aus und schicke dir gleich ein neues Rücksendelabel. Versand ist für dich kostenlos.', attach: 'label' },
  { role: 'user', time: '09:22', text: 'Perfekt, danke dir 🙏' },
  { role: 'agent', name: 'Mara', time: '09:22', text: 'Sehr gerne. Falls die L doch nicht passt — wir haben gerade eine XL in Grey reinbekommen.' },
];

const ChatScreen = () => (
  <div className="screen chat">
    <aside className="chat__sidebar">
      <header className="chat__sidebar-head">
        <Mono className="muted-text">[ATELIER · SUPPORT]</Mono>
        <h3 className="headline">Gespräche</h3>
      </header>

      <input className="chat__search" placeholder="Suchen…" />

      <ul className="chat__list">
        {[
          ['Mara', 'Wir tauschen die Größe aus…', '09:22', true, 'M'],
          ['Felix', 'Wegen der Iced Green Watch…', 'Gestern', false, 'F'],
          ['Tessa', 'Lieferung kommt morgen.', 'Mo', false, 'T'],
          ['Kim', 'Danke für die Hilfe.', '07. Mai', false, 'K'],
          ['Bot', 'Rückgabe eingeleitet.', '02. Mai', false, 'B'],
        ].map(([name, snippet, time, active, initial], i) => (
          <li key={i} className={`chat-conv${active ? ' chat-conv--active' : ''}`}>
            <span className="chat-conv__avatar">{initial}</span>
            <div className="chat-conv__body">
              <div className="chat-conv__top">
                <span className="chat-conv__name">{name}</span>
                <Mono className="muted-text">{time}</Mono>
              </div>
              <span className="chat-conv__snippet">{snippet}</span>
            </div>
            {active && <span className="chat-conv__pip" />}
          </li>
        ))}
      </ul>

      <footer className="chat__sidebar-foot">
        <span className="chat__user">
          <span className="chat__user-avatar">A</span>
          <div>
            <span className="chat__user-name">Alice Müller</span>
            <Mono className="muted-text">Mitglied seit Feb 2026</Mono>
          </div>
        </span>
      </footer>
    </aside>

    <main className="chat__main">
      <header className="chat__head">
        <div className="chat__head-agent">
          <span className="chat__avatar chat__avatar--lg">M</span>
          <div>
            <h4 className="chat__head-name">Mara · Norevan Atelier</h4>
            <span className="chat__online">
              <span className="dot dot--ok" /> Online · antwortet meist in 2 Min
            </span>
          </div>
        </div>
        <div className="chat__head-tools">
          <Pill variant="ghost" size="sm">Bestellungen ansehen</Pill>
          <Pill variant="ghost" size="sm">Anruf anfordern</Pill>
        </div>
      </header>

      <div className="chat__bg">
        <img src="assets/chat-bg.jpg" alt="" />
        <div className="chat__bg-veil" />
      </div>

      <div className="chat__stream">
        <div className="chat__day">
          <span className="chat__day-line" />
          <Mono className="muted-text">Heute · 14. Mai 2026</Mono>
          <span className="chat__day-line" />
        </div>

        {messages.map((m, i) => (
          <div key={i} className={`bubble bubble--${m.role} anim-rise`} style={{ '--d': `${i * 90}ms` }}>
            {m.role === 'agent' && <span className="bubble__avatar">M</span>}
            <div className="bubble__inner">
              {m.role === 'agent' && (
                <header className="bubble__head">
                  <span className="bubble__name">{m.name}</span>
                  <Mono className="muted-text">Norevan Atelier</Mono>
                </header>
              )}
              <p>{m.text}</p>
              {m.attach === 'label' && (
                <div className="bubble__attach">
                  <span className="attach-icon">↧</span>
                  <div>
                    <span className="attach__name">Rücksendelabel_N-00428.pdf</span>
                    <Mono className="muted-text">PDF · 82 KB</Mono>
                  </div>
                  <a className="link link--muted">Öffnen</a>
                </div>
              )}
              <Mono className="muted-text bubble__time">{m.time}</Mono>
            </div>
          </div>
        ))}

        <div className="bubble bubble--agent typing anim-rise" style={{ '--d': '700ms' }}>
          <span className="bubble__avatar">M</span>
          <div className="bubble__inner bubble__inner--typing">
            <span className="typing-dot" />
            <span className="typing-dot" />
            <span className="typing-dot" />
          </div>
        </div>
      </div>

      <div className="chat__quick">
        {['Rückgabe starten', 'Lieferstatus prüfen', 'Größenberatung', 'Mit Mensch sprechen'].map((q, i) => (
          <button key={i} className="quick-chip">
            <span className="button-label">{q}</span>
          </button>
        ))}
      </div>

      <footer className="chat__composer">
        <button className="composer__icon" aria-label="Anhängen">+</button>
        <input className="composer__input" placeholder="Schreibe Mara eine Nachricht…" />
        <button className="composer__icon">⌘</button>
        <Pill variant="solid" size="sm">Senden →</Pill>
      </footer>
    </main>
  </div>
);

Object.assign(window, { EmailScreen, ChatScreen });
