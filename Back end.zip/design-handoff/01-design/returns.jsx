/* global React, Eyebrow, Mono, Pill, SiteHeader, NorevanMark */

// ============================================================
// QR Code — Inline SVG mit deterministischem Pseudo-Pattern
// (Scannt nicht, sieht aber wie ein echter QR aus.)
// ============================================================
const QRCode = ({ size = 280, seed = 'NRV-N00428-RETURN' }) => {
  const cells = 25;
  // Drei Finder-Muster in den Ecken
  const inFinder = (x, y, cx, cy) => {
    const dx = Math.abs(x - cx);
    const dy = Math.abs(y - cy);
    if (dx > 3 || dy > 3) return null;
    const max = Math.max(dx, dy);
    if (max === 0 || max === 1 || max === 3) return 1;
    return 0;
  };
  // Deterministischer Hash für Pseudo-Daten
  const seedSum = seed.split('').reduce((s, c) => s + c.charCodeAt(0), 0);
  const cell = (x, y) => {
    const f1 = inFinder(x, y, 3, 3);
    const f2 = inFinder(x, y, cells - 4, 3);
    const f3 = inFinder(x, y, 3, cells - 4);
    if (f1 !== null) return f1;
    if (f2 !== null) return f2;
    if (f3 !== null) return f3;
    // Schutzzone um die Finder
    if ((x === 7 && y <= 7) || (y === 7 && x <= 7)) return 0;
    if ((x === cells - 8 && y <= 7) || (y === 7 && x >= cells - 8)) return 0;
    if ((x === 7 && y >= cells - 8) || (y === cells - 8 && x <= 7)) return 0;
    // Timing-Linien
    if (x === 6 && y > 7 && y < cells - 8) return (y + 1) % 2;
    if (y === 6 && x > 7 && x < cells - 8) return (x + 1) % 2;
    // Pseudo-Daten
    const h = ((x * 73856093) ^ (y * 19349663) ^ (seedSum * 83492791)) >>> 0;
    return (h % 100) > 52 ? 1 : 0;
  };

  const dots = [];
  for (let y = 0; y < cells; y++) {
    for (let x = 0; x < cells; x++) {
      if (cell(x, y)) {
        dots.push(<rect key={`${x}-${y}`} x={x} y={y} width="1" height="1" fill="currentColor" />);
      }
    }
  }

  return (
    <svg width={size} height={size} viewBox={`0 0 ${cells} ${cells}`}
         shapeRendering="crispEdges" aria-label="QR-Code">
      {dots}
      {/* Mittiges Logo-Plättchen mit Norevan-N */}
      <rect x={cells / 2 - 2.5} y={cells / 2 - 2.5} width="5" height="5" fill="white" />
      <text x={cells / 2} y={cells / 2 + 1.4}
            fontFamily='"Cormorant Garamond", Georgia, serif'
            fontSize="4" fontStyle="italic"
            textAnchor="middle" fill="currentColor">N</text>
    </svg>
  );
};

// ============================================================
// RETURN METHOD — Methode für die Rücksendung wählen
// ============================================================
const ReturnMethodScreen = () => {
  const item = {
    brand: 'Nike',
    name: 'Tech Fleece Crew · Grey',
    size: 'M',
    price: 189,
    img: 'assets/product-fleece.png',
    reason: 'Größe zu eng — tausche gegen L',
  };

  return (
    <div className="screen returns">
      <SiteHeader cart={3} />

      <div className="returns__intro anim-rise" style={{ '--d': '0ms' }}>
        <div>
          <Mono className="muted-text">[RÜCKGABE · BESTELLUNG #N-00428]</Mono>
          <h1 className="returns__title">
            Rückversand <span className="returns__title-sub">in zwei Minuten</span>
          </h1>
        </div>
        <a className="link link--muted">← Zur Bestellung</a>
      </div>

      <div className="returns__progress anim-rise" style={{ '--d': '80ms' }}>
        <span className="step step--done"><Mono>01</Mono> Artikel</span>
        <span className="step__line" />
        <span className="step step--done"><Mono>02</Mono> Grund</span>
        <span className="step__line" />
        <span className="step step--current"><Mono>03</Mono> Versandmethode</span>
        <span className="step__line" />
        <span className="step"><Mono>04</Mono> Bestätigung</span>
      </div>

      <div className="returns__layout">
        <div className="returns__methods">
          <header className="returns__section-head anim-rise" style={{ '--d': '160ms' }}>
            <Eyebrow>Schritt 03 · Wähle wie du zurücksendest</Eyebrow>
            <h2 className="returns__section-title">
              Drei Wege, <span className="headline-italic">wähle deinen.</span>
            </h2>
          </header>

          <div className="method-list">
            <article className="method-card method-card--active anim-rise" style={{ '--d': '240ms' }}>
              <span className="method-card__badge">
                <Mono>Empfohlen</Mono>
              </span>
              <div className="method-card__head">
                <div className="method-card__icon">
                  <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <rect x="4" y="4" width="10" height="10" />
                    <rect x="18" y="4" width="10" height="10" />
                    <rect x="4" y="18" width="10" height="10" />
                    <rect x="7" y="7" width="4" height="4" fill="currentColor" />
                    <rect x="21" y="7" width="4" height="4" fill="currentColor" />
                    <rect x="7" y="21" width="4" height="4" fill="currentColor" />
                    <rect x="20" y="20" width="2" height="2" fill="currentColor" />
                    <rect x="24" y="24" width="2" height="2" fill="currentColor" />
                    <rect x="20" y="26" width="2" height="2" fill="currentColor" />
                    <rect x="26" y="20" width="2" height="2" fill="currentColor" />
                  </svg>
                </div>
                <div className="method-card__body">
                  <h3 className="method-card__name">QR-Code im Paketshop</h3>
                  <p className="method-card__desc">
                    Zeige den Code an der Theke. Kein Drucken, kein Etikett kleben.
                    Über 26.000 DHL-Standorte in Deutschland.
                  </p>
                  <div className="method-card__meta">
                    <Mono className="muted-text">Erstattung in 3–5 Werktagen</Mono>
                    <span className="method-card__price">Kostenlos</span>
                  </div>
                </div>
                <span className="radio radio--lg radio--checked" />
              </div>
            </article>

            <article className="method-card anim-rise" style={{ '--d': '320ms' }}>
              <div className="method-card__head">
                <div className="method-card__icon">
                  <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <rect x="6" y="4" width="20" height="24" />
                    <line x1="10" y1="10" x2="22" y2="10" />
                    <line x1="10" y1="14" x2="22" y2="14" />
                    <line x1="10" y1="18" x2="18" y2="18" />
                    <rect x="14" y="22" width="6" height="4" fill="currentColor" />
                  </svg>
                </div>
                <div className="method-card__body">
                  <h3 className="method-card__name">PDF-Label drucken</h3>
                  <p className="method-card__desc">
                    Wir senden dir das Versandetikett als PDF. Drucken, aufkleben,
                    im Paketshop abgeben oder von DHL abholen lassen.
                  </p>
                  <div className="method-card__meta">
                    <Mono className="muted-text">Erstattung in 5–7 Werktagen</Mono>
                    <span className="method-card__price">Kostenlos</span>
                  </div>
                </div>
                <span className="radio radio--lg" />
              </div>
            </article>

            <article className="method-card anim-rise" style={{ '--d': '400ms' }}>
              <div className="method-card__head">
                <div className="method-card__icon">
                  <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M4 16 L16 6 L28 16 V26 H4 Z" />
                    <line x1="12" y1="26" x2="12" y2="18" />
                    <line x1="20" y1="26" x2="20" y2="18" />
                    <line x1="12" y1="18" x2="20" y2="18" />
                  </svg>
                </div>
                <div className="method-card__body">
                  <h3 className="method-card__name">Hausabholung durch DHL</h3>
                  <p className="method-card__desc">
                    Du wählst Datum und Zeitfenster — der Fahrer kommt zu dir
                    nach Hause oder ins Büro. Bequemer geht es nicht.
                  </p>
                  <div className="method-card__meta">
                    <Mono className="muted-text">Erstattung in 4–6 Werktagen</Mono>
                    <span className="method-card__price">€ 4,90</span>
                  </div>
                </div>
                <span className="radio radio--lg" />
              </div>
            </article>
          </div>

          <div className="returns__faq anim-rise" style={{ '--d': '500ms' }}>
            <Eyebrow>Häufig gefragt</Eyebrow>
            <details className="faq-item" open>
              <summary>Wie lange dauert die Erstattung?</summary>
              <p>Sobald wir dein Paket erhalten haben, prüfen wir es innerhalb von 24 Stunden und veranlassen die Rückerstattung auf das ursprüngliche Zahlungsmittel.</p>
            </details>
            <details className="faq-item">
              <summary>Muss ich den Originalkarton behalten?</summary>
              <p>Nein. Du kannst jeden stabilen Karton verwenden — Hauptsache der Artikel kommt unbeschädigt bei uns an.</p>
            </details>
            <details className="faq-item">
              <summary>Kann ich gegen eine andere Größe tauschen?</summary>
              <p>Ja. Wähle im Schritt davor „Tausch" statt „Rückgabe" — wir senden dir die neue Größe automatisch zu, sobald wir das Paket erhalten haben.</p>
            </details>
          </div>
        </div>

        <aside className="returns__summary anim-rise" style={{ '--d': '280ms' }}>
          <Eyebrow>Du sendest zurück</Eyebrow>

          <div className="return-item">
            <div className="return-item__media">
              <img src={item.img} alt="" />
            </div>
            <div className="return-item__info">
              <Mono className="muted-text">{item.brand}</Mono>
              <h4 className="return-item__name">{item.name}</h4>
              <Mono className="muted-text">Größe {item.size} · 1 Stück</Mono>
            </div>
            <span className="price-display price-display--sm">€ {item.price}</span>
          </div>

          <dl className="summary__list summary__list--compact">
            <div><dt>Grund</dt><dd>Größe</dd></div>
            <div><dt>Wunsch</dt><dd>Tausch gegen L</dd></div>
            <div><dt>Versand</dt><dd className="summary__free">Kostenlos</dd></div>
          </dl>

          <div className="summary__total">
            <span className="button-label muted-text">Erstattung</span>
            <span className="summary__big">€ {item.price}</span>
          </div>

          <Pill variant="solid">QR-Code generieren →</Pill>

          <ul className="summary__assurances">
            <li>
              <span className="assurance-mark">✓</span>
              <div>
                <span className="assurance-title">14 Tage Frist</span>
                <Mono className="muted-text">Bis 28. Mai 2026</Mono>
              </div>
            </li>
            <li>
              <span className="assurance-mark">✓</span>
              <div>
                <span className="assurance-title">Geld zurück, nicht Gutschein</span>
                <Mono className="muted-text">Auf dein Zahlungsmittel</Mono>
              </div>
            </li>
          </ul>
        </aside>
      </div>
    </div>
  );
};

// ============================================================
// RETURN CONFIRMATION — Bestätigung mit großem QR-Code
// ============================================================
const ReturnConfirmScreen = () => (
  <div className="screen returns confirm">
    <SiteHeader cart={3} />

    <div className="confirm__intro anim-rise" style={{ '--d': '0ms' }}>
      <Mono className="muted-text">[RÜCKGABE · BESTÄTIGT]</Mono>
      <h1 className="confirm__title">
        Erledigt. <span className="headline-italic">Fast.</span>
      </h1>
      <p className="confirm__lede">
        Drei Schritte trennen dich noch vom Rückversand — wir haben sie unten zusammengefasst.
      </p>
    </div>

    <div className="confirm__progress anim-rise" style={{ '--d': '60ms' }}>
      <span className="step step--done"><Mono>01</Mono> Artikel</span>
      <span className="step__line" />
      <span className="step step--done"><Mono>02</Mono> Grund</span>
      <span className="step__line" />
      <span className="step step--done"><Mono>03</Mono> Versandmethode</span>
      <span className="step__line" />
      <span className="step step--current"><Mono>04</Mono> Bestätigung</span>
    </div>

    <div className="confirm__layout">
      <div className="confirm__qr-panel anim-rise" style={{ '--d': '180ms' }}>
        <div className="qr-card">
          <header className="qr-card__head">
            <NorevanMark variant="horizontal" size={18} />
            <Mono className="muted-text">Rücksende-Code</Mono>
          </header>

          <div className="qr-card__main">
            <div className="qr-card__corners">
              <span className="corner corner--tl" />
              <span className="corner corner--tr" />
              <span className="corner corner--bl" />
              <span className="corner corner--br" />
            </div>
            <QRCode size={280} seed="NRV-N00428-RETURN-001" />
          </div>

          <footer className="qr-card__foot">
            <div>
              <Mono className="muted-text">Code</Mono>
              <span className="qr-card__code">NRV-N00428-001</span>
            </div>
            <div>
              <Mono className="muted-text">Gültig bis</Mono>
              <span>28. Mai 2026</span>
            </div>
          </footer>
        </div>

        <div className="qr-actions">
          <Pill variant="ghost">Als PDF speichern</Pill>
          <Pill variant="ghost">Per E-Mail senden</Pill>
          <Pill variant="ghost">Zum Wallet</Pill>
        </div>
      </div>

      <div className="confirm__steps anim-rise" style={{ '--d': '280ms' }}>
        <Eyebrow>So geht es weiter</Eyebrow>
        <ol className="how-steps">
          <li className="how-step">
            <span className="how-step__num">01</span>
            <div>
              <h4>Verpacke den Artikel</h4>
              <p>Originalkarton bevorzugt — jeder stabile Karton geht aber auch. Beilage, Etiketten und Schuhkarton mit einlegen.</p>
            </div>
          </li>
          <li className="how-step">
            <span className="how-step__num">02</span>
            <div>
              <h4>Gehe in einen DHL-Paketshop</h4>
              <p>Über 26.000 Standorte. Wir zeigen dir oben rechts die drei nächsten — der Filialfinder ist drei Klicks entfernt.</p>
              <a className="link">Paketshops in der Nähe →</a>
            </div>
          </li>
          <li className="how-step">
            <span className="how-step__num">03</span>
            <div>
              <h4>Zeige den QR-Code an der Theke</h4>
              <p>Der Mitarbeiter scannt — du gibst das Paket ab — fertig. Kein Etikett kleben, kein Drucken, kein Wiegen.</p>
            </div>
          </li>
        </ol>

        <div className="confirm__locator">
          <div className="locator__head">
            <Eyebrow>DHL-Paketshops in deiner Nähe</Eyebrow>
            <Mono className="muted-text">Berlin · 10115</Mono>
          </div>
          <ul className="locator__list">
            <li>
              <div>
                <h5>Späti am Rosenthaler</h5>
                <Mono className="muted-text">Rosenthaler Str. 39 · 220 m</Mono>
              </div>
              <Mono className="muted-text">Offen bis 22:00</Mono>
            </li>
            <li>
              <div>
                <h5>DHL-Paketshop Kollwitzplatz</h5>
                <Mono className="muted-text">Wörther Str. 28 · 480 m</Mono>
              </div>
              <Mono className="muted-text">Offen bis 20:00</Mono>
            </li>
            <li>
              <div>
                <h5>Tabakwaren Mitte</h5>
                <Mono className="muted-text">Torstraße 142 · 610 m</Mono>
              </div>
              <Mono className="muted-text">Offen bis 19:00</Mono>
            </li>
          </ul>
        </div>

        <div className="confirm__status">
          <div>
            <Mono className="muted-text">Geschätzte Erstattung</Mono>
            <span className="confirm__status-date">19.–21. Mai 2026</span>
          </div>
          <div>
            <Mono className="muted-text">Bestätigung gesendet</Mono>
            <span className="confirm__status-mail">alice@beispiel.de</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

Object.assign(window, { QRCode, ReturnMethodScreen, ReturnConfirmScreen });
