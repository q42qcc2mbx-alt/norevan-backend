/* global React, ReactDOM,
   Eyebrow, Mono, Pill, Field, Divider, Logo,
   CartScreen, CheckoutScreen, EmailScreen, ChatScreen */

// ============================================================
// LOGIN — split editorial
// ============================================================
const LoginScreen = () => (
  <div className="screen screen--split">
    <aside className="screen__media">
      <img src="assets/lifestyle-1.jpg" alt="" />
      <div className="screen__media-overlay" />
      <div className="screen__media-meta">
        <Mono>Norevan · Atelier Access</Mono>
        <p className="quote headline-italic">
          "The door is small. <br />
          The room is yours."
        </p>
        <Mono className="muted-text">Saison 2026 · Mitgliederzugang</Mono>
      </div>
      <div className="screen__media-counter">
        <Mono>01 / 02</Mono>
      </div>
    </aside>

    <section className="screen__form">
      <header className="form__header">
        <Mono className="muted-text">[ANMELDEN]</Mono>
      </header>

      <div className="form__body">
        <div className="anim-rise" style={{ '--d': '0ms' }}>
          <Eyebrow>Willkommen zurück</Eyebrow>
        </div>
        <h1 className="headline anim-rise" style={{ '--d': '80ms' }}>
          Identifiziere <span className="headline-italic">dich.</span>
        </h1>
        <p className="form__sub anim-rise" style={{ '--d': '180ms' }}>
          Mitgliederzugang zum Norevan-Backend. Token wird für 1 Stunde signiert.
        </p>

        <div className="form__fields">
          <div className="anim-rise" style={{ '--d': '260ms' }}>
            <Field label="Benutzername" placeholder="alice" value="alice" autoFocus />
          </div>
          <div className="anim-rise" style={{ '--d': '320ms' }}>
            <Field
              label="Passwort"
              type="password"
              placeholder="••••••••"
              value="supersecret"
              hint="Mindestens 8 Zeichen. Wird mit bcrypt (cost 12) gehasht."
            />
          </div>
          <div className="form__row anim-rise" style={{ '--d': '380ms' }}>
            <label className="checkbox">
              <input type="checkbox" defaultChecked />
              <span>Angemeldet bleiben</span>
            </label>
            <a className="link" href="#">Passwort vergessen</a>
          </div>
        </div>

        <div className="form__actions anim-rise" style={{ '--d': '440ms' }}>
          <Pill variant="solid">Anmelden →</Pill>
          <a className="link link--muted" href="#">Noch kein Konto? Registrieren</a>
        </div>

        <Divider>oder</Divider>

        <div className="form__alt anim-rise" style={{ '--d': '520ms' }}>
          <Pill variant="ghost">Mit Passkey fortfahren</Pill>
          <Mono className="muted-text alt-hint">
            POST /api/auth/login · returns Bearer Token
          </Mono>
        </div>
      </div>

      <footer className="form__footer">
        <Mono className="muted-text">© Norevan 2026</Mono>
        <Mono className="muted-text">Made with code &amp; coffee.</Mono>
      </footer>
    </section>
  </div>
);

// ============================================================
// REGISTER — centered on full-bleed
// ============================================================
const RegisterScreen = () => (
  <div className="screen screen--bleed">
    <img className="bleed__img" src="assets/lifestyle-2.jpg" alt="" />
    <div className="bleed__veil" />

    <header className="bleed__topbar">
      <Mono className="muted-text">02 / 02 · REGISTRIERUNG</Mono>
      <Pill variant="ghost-dark" as="a" href="#">Bereits dabei? Anmelden</Pill>
    </header>

    <div className="bleed__card anim-rise" style={{ '--d': '120ms' }}>
      <Eyebrow>Neues Konto</Eyebrow>
      <h2 className="headline">
        Tritt dem <span className="headline-italic">Atelier</span> bei.
      </h2>
      <p className="form__sub">
        Drei Zeilen. Kein Newsletter, keine Bestätigungsmail.
        Dein Konto existiert in dem Moment, in dem du sendest.
      </p>

      <div className="form__fields">
        <Field label="Benutzername" placeholder="Wähle einen Namen" hint="Min. 3 Zeichen · einmalig" />
        <Field label="Passwort" type="password" placeholder="••••••••" hint="Min. 8 Zeichen" />
        <Field label="Passwort bestätigen" type="password" placeholder="••••••••" />
      </div>

      <div className="form__terms">
        <label className="checkbox">
          <input type="checkbox" />
          <span>
            Ich akzeptiere die <a className="link" href="#">Nutzungsbedingungen</a> und{' '}
            <a className="link" href="#">Datenschutzerklärung</a>.
          </span>
        </label>
      </div>

      <div className="form__actions form__actions--stacked">
        <Pill variant="solid">Konto erstellen →</Pill>
        <Mono className="muted-text">
          POST /api/auth/register · 201 Created
        </Mono>
      </div>
    </div>

    <footer className="bleed__footer">
      <Mono className="muted-text">Norevan · Backend v1.0</Mono>
      <Mono className="muted-text">Tokens · bcrypt · sqlite</Mono>
    </footer>
  </div>
);

// ============================================================
// DASHBOARD — post-login editorial
// ============================================================
const DashboardScreen = () => (
  <div className="screen dashboard">
    <header className="dash__header">
      <div className="dash__brand">
        <NorevanMark variant="horizontal" size={22} />
        <Mono className="muted-text">[ATELIER]</Mono>
      </div>
      <nav className="dash__nav">
        <a className="dash__nav-item dash__nav-item--active">Übersicht</a>
        <a className="dash__nav-item">Profil</a>
        <a className="dash__nav-item">Token</a>
        <a className="dash__nav-item">Aktivität</a>
      </nav>
      <div className="dash__user">
        <Mono className="muted-text">Eingeloggt als</Mono>
        <span className="dash__user-name">alice</span>
        <span className="dash__avatar">A</span>
      </div>
    </header>

    <main className="dash__main">
      <section className="dash__hero anim-rise" style={{ '--d': '0ms' }}>
        <Eyebrow>Sitzung aktiv · 14. Mai 2026, 09:24</Eyebrow>
        <h1 className="headline dash__title">
          Willkommen zurück, <span className="headline-italic">Alice.</span>
        </h1>
        <p className="dash__lede">
          Dein Token ist signiert und gültig. Bewege dich frei durch die geschützten Routen.
        </p>
      </section>

      <section className="dash__grid">
        <article className="card card--id anim-rise" style={{ '--d': '120ms' }}>
          <Mono className="muted-text">Mitglied</Mono>
          <div className="card__big-id">
            <span className="card__hash">#</span>
            <span className="card__num">00042</span>
          </div>
          <div className="card__meta">
            <div>
              <Mono className="muted-text">Beigetreten</Mono>
              <span>14. Feb 2026</span>
            </div>
            <div>
              <Mono className="muted-text">Status</Mono>
              <span className="dot dot--ok" /> Aktiv
            </div>
          </div>
        </article>

        <article className="card card--token anim-rise" style={{ '--d': '200ms' }}>
          <header className="card__head">
            <Mono className="muted-text">Aktuelles JWT</Mono>
            <Mono className="muted-text">Läuft ab in 58 min</Mono>
          </header>
          <code className="card__token">
            eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.
            <wbr />eyJzdWIiOjQyLCJ1c2VybmFtZSI6ImFsaWNlIiwiaWF0IjoxNzQ3Mzg…
          </code>
          <div className="card__actions">
            <Pill variant="ghost">Kopieren</Pill>
            <Pill variant="ghost">Neu erstellen</Pill>
            <Pill variant="ghost-danger">Widerrufen</Pill>
          </div>
        </article>

        <article className="card card--stat anim-rise" style={{ '--d': '280ms' }}>
          <Mono className="muted-text">Anfragen heute</Mono>
          <div className="stat__num">128</div>
          <Mono className="muted-text stat__trend">↑ 18 % ggü. gestern</Mono>
        </article>

        <article className="card card--stat anim-rise" style={{ '--d': '340ms' }}>
          <Mono className="muted-text">Letzter Login</Mono>
          <div className="stat__num stat__num--sm">vor 4 Min</div>
          <Mono className="muted-text">Berlin · 91.64.xx.xx</Mono>
        </article>
      </section>

      <section className="dash__activity anim-rise" style={{ '--d': '420ms' }}>
        <header className="activity__head">
          <Eyebrow>Letzte Aktivität</Eyebrow>
          <a className="link link--muted">Alle anzeigen →</a>
        </header>
        <ol className="activity__list">
          {[
            ['09:24', 'GET', '/api/dashboard', '200 OK', 'ok'],
            ['09:24', 'POST', '/api/auth/login', '200 OK', 'ok'],
            ['08:11', 'GET', '/api/dashboard', '401 Unauthorized', 'warn'],
            ['Gestern · 22:40', 'POST', '/api/auth/login', '401 Unauthorized', 'warn'],
            ['Gestern · 18:02', 'POST', '/api/auth/register', '201 Created', 'ok'],
          ].map(([time, method, path, status, kind], i) => (
            <li key={i} className="activity__row">
              <Mono className="muted-text activity__time">{time}</Mono>
              <span className={`method method--${method.toLowerCase()}`}>{method}</span>
              <code className="activity__path">{path}</code>
              <span className={`status status--${kind}`}>{status}</span>
            </li>
          ))}
        </ol>
      </section>
    </main>
  </div>
);

// ============================================================
// Mount
// ============================================================
function App() {
  return (
    <DesignCanvas title="Norevan · Backend Atelier" subtitle="Auth · Commerce · Comms">
      <DCSection id="auth" title="Auth Flow" subtitle="Editorial gate — split + full-bleed">
        <DCArtboard id="login" label="Login" width={1440} height={900}>
          <LoginScreen />
        </DCArtboard>
        <DCArtboard id="register" label="Registrierung" width={1440} height={960}>
          <RegisterScreen />
        </DCArtboard>
      </DCSection>

      <DCSection id="dashboard" title="Member Dashboard" subtitle="Geschützte Route · /api/dashboard">
        <DCArtboard id="dashboard-main" label="Dashboard" width={1440} height={1120}>
          <DashboardScreen />
        </DCArtboard>
      </DCSection>

      <DCSection id="commerce" title="Commerce" subtitle="Warenkorb &amp; Bezahlung — editorial cart">
        <DCArtboard id="cart" label="Warenkorb" width={1440} height={1100}>
          <CartScreen />
        </DCArtboard>
        <DCArtboard id="checkout" label="Bezahlung" width={1440} height={1200}>
          <CheckoutScreen />
        </DCArtboard>
      </DCSection>

      <DCSection id="comms" title="Comms" subtitle="E-Mail &amp; Support — wie wir mit Mitgliedern sprechen">
        <DCArtboard id="email" label="E-Mail Template" width={1440} height={1500}>
          <EmailScreen />
        </DCArtboard>
        <DCArtboard id="chat" label="Support Chat" width={1440} height={1000}>
          <ChatScreen />
        </DCArtboard>
      </DCSection>

      <DCSection id="returns" title="Rückgabe" subtitle="QR-Code, PDF oder Hausabholung">
        <DCArtboard id="return-method" label="Rückgabe · Methode wählen" width={1440} height={1440}>
          <ReturnMethodScreen />
        </DCArtboard>
        <DCArtboard id="return-confirm" label="Rückgabe · Bestätigung" width={1440} height={1400}>
          <ReturnConfirmScreen />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
