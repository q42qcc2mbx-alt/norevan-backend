/* global React, Eyebrow, Mono, Pill, Field, Divider, SiteHeader */

// ============================================================
// CART — Editorial Warenkorb-Seite
// ============================================================
const cartItems = [
  {
    id: 1,
    brand: 'Nike',
    name: 'Tech Fleece Crew · Grey',
    size: 'M',
    qty: 1,
    price: 189,
    img: 'assets/product-fleece.png',
  },
  {
    id: 2,
    brand: 'Ralph Lauren',
    name: 'Classic Court Sneaker',
    size: '43',
    qty: 1,
    price: 249,
    img: 'assets/product-sneaker.png',
  },
  {
    id: 3,
    brand: 'Maison Atelier',
    name: 'Iced Green Watch',
    size: '40 mm',
    qty: 1,
    price: 1290,
    img: 'assets/product-watch.png',
  },
];

const CartScreen = () => {
  const subtotal = cartItems.reduce((s, i) => s + i.price * i.qty, 0);
  const vat = Math.round(subtotal * 0.19);
  return (
    <div className="screen cart">
      <SiteHeader cart={cartItems.length} />

      <div className="cart__intro anim-rise" style={{ '--d': '0ms' }}>
        <div className="cart__intro-left">
          <Mono className="muted-text">[WARENKORB]</Mono>
          <h1 className="cart__title">
            Warenkorb <span className="cart__count">{cartItems.length} Artikel</span>
          </h1>
        </div>
        <a className="link link--muted cart__continue">← Weiter einkaufen</a>
      </div>

      <div className="cart__layout">
        <div className="cart__table">
          <header className="cart__table-head">
            <span>Artikel</span>
            <span>Menge</span>
            <span>Preis</span>
            <span />
          </header>

          <ol className="cart__items">
            {cartItems.map((item, i) => (
              <li key={item.id} className="cart-item anim-rise" style={{ '--d': `${120 + i * 80}ms` }}>
                <div className="cart-item__product">
                  <div className="cart-item__media">
                    <img src={item.img} alt="" />
                  </div>
                  <div className="cart-item__info">
                    <Mono className="muted-text">{item.brand}</Mono>
                    <h4 className="cart-item__name">{item.name}</h4>
                    <Mono className="muted-text cart-item__meta-line">
                      Größe {item.size} · auf Lager
                    </Mono>
                  </div>
                </div>

                <div className="qty">
                  <button className="qty__btn">−</button>
                  <span className="qty__num">{item.qty}</span>
                  <button className="qty__btn">+</button>
                </div>

                <div className="cart-item__price">
                  <span className="price-display price-display--sm">€ {item.price.toLocaleString('de-DE')}</span>
                  <Mono className="muted-text">pro Stück</Mono>
                </div>

                <button className="cart-item__remove" aria-label="Entfernen">×</button>
              </li>
            ))}
          </ol>

          <footer className="cart__table-foot">
            <Mono className="muted-text">Alle Preise inkl. MwSt.</Mono>
            <span className="cart__subtotal-line">
              Zwischensumme · <span className="price-display price-display--sm">€ {subtotal.toLocaleString('de-DE')}</span>
            </span>
          </footer>
        </div>

        <aside className="cart__summary anim-rise" style={{ '--d': '380ms' }}>
          <header className="summary__head">
            <Eyebrow>Bestellübersicht</Eyebrow>
          </header>

          <dl className="summary__list">
            <div><dt>Zwischensumme</dt><dd>€ {subtotal.toLocaleString('de-DE')}</dd></div>
            <div><dt>Versand · Standard</dt><dd className="summary__free">Kostenlos</dd></div>
            <div><dt>MwSt. (19 %)</dt><dd>€ {vat.toLocaleString('de-DE')}</dd></div>
          </dl>

          <div className="promo">
            <input className="field__input" placeholder="Promo-Code" />
            <button className="promo__btn">Einlösen</button>
          </div>

          <div className="summary__total">
            <span className="button-label muted-text">Gesamt</span>
            <span className="summary__big">€ {subtotal.toLocaleString('de-DE')}</span>
          </div>

          <Pill variant="solid">Zur Kasse →</Pill>

          <div className="summary__pay">
            <Mono className="muted-text">Sicher bezahlen mit</Mono>
            <div className="pay-icons">
              {['VISA', 'MC', 'PayPal', 'Apple Pay', 'Klarna'].map((p) => (
                <span key={p} className="pay-icon">{p}</span>
              ))}
            </div>
          </div>

          <ul className="summary__assurances">
            <li>
              <span className="assurance-mark">✓</span>
              <div>
                <span className="assurance-title">Kostenloser Versand</span>
                <Mono className="muted-text">Lieferung in 1–3 Werktagen</Mono>
              </div>
            </li>
            <li>
              <span className="assurance-mark">✓</span>
              <div>
                <span className="assurance-title">30 Tage Rückgaberecht</span>
                <Mono className="muted-text">Frei &amp; ohne Angabe von Gründen</Mono>
              </div>
            </li>
            <li>
              <span className="assurance-mark">✓</span>
              <div>
                <span className="assurance-title">Authentizität garantiert</span>
                <Mono className="muted-text">Jedes Stück handgeprüft</Mono>
              </div>
            </li>
          </ul>
        </aside>
      </div>
    </div>
  );
};

// ============================================================
// CHECKOUT — Bezahlung
// ============================================================
const CheckoutScreen = () => (
  <div className="screen checkout">
    <SiteHeader cart={3} />

    <div className="checkout__progress anim-rise" style={{ '--d': '0ms' }}>
      <span className="step step--done"><Mono>01</Mono> Warenkorb</span>
      <span className="step__line" />
      <span className="step step--done"><Mono>02</Mono> Versand</span>
      <span className="step__line" />
      <span className="step step--current"><Mono>03</Mono> Bezahlung</span>
    </div>

    <div className="checkout__layout">
      <div className="checkout__form anim-rise" style={{ '--d': '120ms' }}>
        <section className="check-block">
          <Eyebrow>Lieferadresse</Eyebrow>
          <div className="check-address">
            <h4>Alice Müller</h4>
            <p>Linienstraße 142<br />10115 Berlin · Deutschland</p>
            <a className="link link--muted">Adresse ändern</a>
          </div>
        </section>

        <section className="check-block">
          <Eyebrow>Versandart</Eyebrow>
          <ul className="radio-list">
            <li className="radio-row radio-row--active">
              <span className="radio" />
              <div>
                <h4>Standard · Kostenlos</h4>
                <Mono className="muted-text">Lieferung 14.–16. Mai · DHL</Mono>
              </div>
              <span className="price-display price-display--xs">€ 0</span>
            </li>
            <li className="radio-row">
              <span className="radio" />
              <div>
                <h4>Express · Übernacht</h4>
                <Mono className="muted-text">Morgen vor 12:00 · DHL Express</Mono>
              </div>
              <span className="price-display price-display--xs">€ 19</span>
            </li>
          </ul>
        </section>

        <section className="check-block">
          <Eyebrow>Bezahlmethode</Eyebrow>
          <div className="pay-tabs">
            {[
              ['Karte', true],
              ['PayPal', false],
              ['Apple Pay', false],
              ['Klarna', false],
              ['SEPA', false],
            ].map(([label, active], i) => (
              <button key={i} className={`pay-tab${active ? ' pay-tab--active' : ''}`}>
                <span className="button-label">{label}</span>
              </button>
            ))}
          </div>

          <div className="card-form">
            <Field label="Karteninhaber" placeholder="Alice Müller" value="Alice Müller" />
            <div className="card-form__num">
              <Field label="Kartennummer" placeholder="•••• •••• •••• 4242" value="4242 4242 4242 4242" />
              <div className="card-brands">
                <span className="brand-pill">VISA</span>
                <span className="brand-pill">MC</span>
              </div>
            </div>
            <div className="card-form__row">
              <Field label="Gültig bis" placeholder="MM / JJ" value="08 / 28" />
              <Field label="CVC" placeholder="•••" value="123" />
            </div>
          </div>
        </section>

        <label className="checkbox checkbox--lg">
          <input type="checkbox" defaultChecked />
          <span>Rechnungsadresse entspricht der Lieferadresse.</span>
        </label>
      </div>

      <aside className="checkout__summary anim-rise" style={{ '--d': '240ms' }}>
        <Eyebrow>Deine Bestellung</Eyebrow>
        <ol className="mini-items">
          {cartItems.map((item) => (
            <li key={item.id} className="mini-item">
              <div className="mini-item__media">
                <img src={item.img} alt="" />
                <span className="mini-item__badge">{item.qty}</span>
              </div>
              <div className="mini-item__body">
                <Mono className="muted-text">{item.brand}</Mono>
                <span className="mini-item__name">{item.name}</span>
                <Mono className="muted-text">Größe {item.size}</Mono>
              </div>
              <span className="price-display price-display--xs">€ {item.price.toLocaleString('de-DE')}</span>
            </li>
          ))}
        </ol>

        <dl className="summary__list summary__list--compact">
          <div><dt>Zwischensumme</dt><dd>€ 1.728</dd></div>
          <div><dt>Versand</dt><dd className="summary__free">Kostenlos</dd></div>
          <div><dt>MwSt. (19 %)</dt><dd>€ 328</dd></div>
        </dl>

        <div className="summary__total">
          <span className="button-label muted-text">Gesamt</span>
          <span className="summary__big">€ 1.728</span>
        </div>

        <Pill variant="solid">Jetzt bezahlen · € 1.728 →</Pill>

        <p className="checkout__legal">
          Mit der Bestellung akzeptierst du unsere <a className="link">AGB</a> und{' '}
          <a className="link">Datenschutzerklärung</a>. Demo-Modus: keine echte Belastung.
        </p>
      </aside>
    </div>
  </div>
);

Object.assign(window, { CartScreen, CheckoutScreen });
